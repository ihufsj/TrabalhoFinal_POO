package Controller;

import java.io.Serializable;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Model.Provider;

public class ProviderJPAController implements Serializable {

	public ProviderJPAController(EntityManagerFactory emf) {
		this.emf = emf;
	}

	private EntityManagerFactory emf = null;

	public EntityManager getEntityManager() {
		return emf.createEntityManager();
	}

	public boolean create(Provider provider) {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			em.persist(provider);
			em.getTransaction().commit();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public void edit(Provider Provider) {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			Provider = em.merge(Provider);
			em.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public void destroy(Integer id) throws Exception {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			Provider uc = new Provider();
			uc.setIdProvider(id);
			em.remove(uc);
			em.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public List<Provider> findProviderEntities() {
		return findProviderEntities(true, -1, -1);
	}

	public List<Provider> findProviderEntities(int maxResults, int firstResult) {
		return findProviderEntities(false, maxResults, firstResult);
	}

	private List<Provider> findProviderEntities(boolean all, int maxResults, int firstResult) {
		EntityManager em = getEntityManager();
		try {
			CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
			cq.select(cq.from(Provider.class));
			Query q = (Query) em.createQuery(cq);
			if (!all) {
				((TypedQuery) q).setMaxResults(maxResults);
				((javax.persistence.Query) q).setFirstResult(firstResult);
			}
			return ((javax.persistence.Query) q).getResultList();
		} finally {
			em.close();
		}
	}

	public Provider findProvider(Integer id) {
		EntityManager em = getEntityManager();
		try {
			return em.find(Provider.class, id);
		} finally {
			em.close();
		}
	}

}
