package Controller;

import java.io.Serializable;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;

import Model.Useraccount;

public class UserAccountJPAController implements Serializable {

	public UserAccountJPAController(EntityManagerFactory emf) {
		this.emf = emf;
	}

	private EntityManagerFactory emf = null;

	public EntityManager getEntityManager() {
		return emf.createEntityManager();
	}

	public boolean create(Useraccount Useraccount) {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			em.persist(Useraccount);
			em.getTransaction().commit();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public void edit(Useraccount Useraccount) {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			Useraccount = em.merge(Useraccount);
			em.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public void destroy(Integer id) throws Exception {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			Useraccount uc = new Useraccount();
			uc.setIdUserAccount(id);
			em.remove(uc);
			em.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public List<Useraccount> findUseraccountEntities() {
		return findUseraccountEntities(true, -1, -1);
	}

	public List<Useraccount> findUseraccountEntities(int maxResults, int firstResult) {
		return findUseraccountEntities(false, maxResults, firstResult);
	}

	private List<Useraccount> findUseraccountEntities(boolean all, int maxResults, int firstResult) {
		EntityManager em = getEntityManager();
		try {
			CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
			cq.select(cq.from(Useraccount.class));
			Query q = (Query) em.createQuery(cq);
			if (!all) {
				((TypedQuery) q).setMaxResults(maxResults);
				((javax.persistence.Query) q).setFirstResult(firstResult);
			}
			return ((javax.persistence.Query) q).getResultList();
		} finally {
			em.close();
		}
	}
	
	public Useraccount findUserAccountByLogin(String login) {
		EntityManager em = getEntityManager();
		Useraccount c = new Useraccount();
		try {
			c =  em.createQuery(
				    "SELECT c FROM Useraccount c WHERE c.loginUserAccount  = :login", Useraccount.class)
				    .setParameter("login", login)
				    .getSingleResult();
			
		} catch(Exception ex){
			ex.printStackTrace();
		}finally {
			em.close();
		}
		return c;
	}

	public Useraccount findUseraccount(Integer id) {
		EntityManager em = getEntityManager();
		try {
			return em.find(Useraccount.class, id);
		} finally {
			em.close();
		}
	}

}
