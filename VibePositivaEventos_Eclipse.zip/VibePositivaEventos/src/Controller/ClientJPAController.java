package Controller;

import java.io.Serializable;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Model.Client;

public class ClientJPAController implements Serializable {

	public ClientJPAController(EntityManagerFactory emf) {
		this.emf = emf;
	}

	private EntityManagerFactory emf = null;

	public EntityManager getEntityManager() {
		return emf.createEntityManager();
	}

	public boolean create(Client Client) {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			em.persist(Client);
			em.getTransaction().commit();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public void edit(Client client) {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			client = em.merge(client);
			em.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public void destroy(Integer id) throws Exception {
		EntityManager em = null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			Client uc = new Client();
			uc.setIdClient(id);
			em.remove(uc);
			em.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	public List<Client> findClientEntities() {
		return findClientEntities(true, -1, -1);
	}

	public List<Client> findClientEntities(int maxResults, int firstResult) {
		return findClientEntities(false, maxResults, firstResult);
	}

	private List<Client> findClientEntities(boolean all, int maxResults, int firstResult) {
		EntityManager em = getEntityManager();
		try {
			CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
			cq.select(cq.from(Client.class));
			Query q = (Query) em.createQuery(cq);
			if (!all) {
				((TypedQuery) q).setMaxResults(maxResults);
				((javax.persistence.Query) q).setFirstResult(firstResult);
			}
			return ((javax.persistence.Query) q).getResultList();
		} finally {
			em.close();
		}
	}

	public Client findClient(Integer id) {
		EntityManager em = getEntityManager();
		try {
			return em.find(Client.class, id);
		} finally {
			em.close();
		}
	}

}
