package Model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the useraccount database table.
 * 
 */
@Entity
@NamedQuery(name="Useraccount.findAll", query="SELECT u FROM Useraccount u")
public class Useraccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int idUserAccount;

	private String emailUserAccount;

	private String loginUserAccount;

	private String nameUserAccount;

	private String passwordUserAccount;

	private String userAccountcol;

	public Useraccount() {
	}

	public int getIdUserAccount() {
		return this.idUserAccount;
	}

	public void setIdUserAccount(int idUserAccount) {
		this.idUserAccount = idUserAccount;
	}

	public String getEmailUserAccount() {
		return this.emailUserAccount;
	}

	public void setEmailUserAccount(String emailUserAccount) {
		this.emailUserAccount = emailUserAccount;
	}

	public String getLoginUserAccount() {
		return this.loginUserAccount;
	}

	public void setLoginUserAccount(String loginUserAccount) {
		this.loginUserAccount = loginUserAccount;
	}

	public String getNameUserAccount() {
		return this.nameUserAccount;
	}

	public void setNameUserAccount(String nameUserAccount) {
		this.nameUserAccount = nameUserAccount;
	}

	public String getPasswordUserAccount() {
		return this.passwordUserAccount;
	}

	public void setPasswordUserAccount(String passwordUserAccount) {
		this.passwordUserAccount = passwordUserAccount;
	}

	public String getUserAccountcol() {
		return this.userAccountcol;
	}

	public void setUserAccountcol(String userAccountcol) {
		this.userAccountcol = userAccountcol;
	}

}