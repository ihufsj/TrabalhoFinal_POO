package Model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the provider database table.
 * 
 */
@Entity
@NamedQuery(name="Provider.findAll", query="SELECT p FROM Provider p")
public class Provider implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int idProvider;

	private String addressProvider;

	private String bankAcProvider;

	private String bankAgProvider;

	private String bankNumberProvider;

	private String cnpjProvider;

	private String nameProvider;

	private String phoneProvider;

	private String typeProvider;

	public Provider() {
	}

	public int getIdProvider() {
		return this.idProvider;
	}

	public void setIdProvider(int idProvider) {
		this.idProvider = idProvider;
	}

	public String getAddressProvider() {
		return this.addressProvider;
	}

	public void setAddressProvider(String addressProvider) {
		this.addressProvider = addressProvider;
	}

	public String getBankAcProvider() {
		return this.bankAcProvider;
	}

	public void setBankAcProvider(String bankAcProvider) {
		this.bankAcProvider = bankAcProvider;
	}

	public String getBankAgProvider() {
		return this.bankAgProvider;
	}

	public void setBankAgProvider(String bankAgProvider) {
		this.bankAgProvider = bankAgProvider;
	}

	public String getBankNumberProvider() {
		return this.bankNumberProvider;
	}

	public void setBankNumberProvider(String bankNumberProvider) {
		this.bankNumberProvider = bankNumberProvider;
	}

	public String getCnpjProvider() {
		return this.cnpjProvider;
	}

	public void setCnpjProvider(String cnpjProvider) {
		this.cnpjProvider = cnpjProvider;
	}

	public String getNameProvider() {
		return this.nameProvider;
	}

	public void setNameProvider(String nameProvider) {
		this.nameProvider = nameProvider;
	}

	public String getPhoneProvider() {
		return this.phoneProvider;
	}

	public void setPhoneProvider(String phoneProvider) {
		this.phoneProvider = phoneProvider;
	}

	public String getTypeProvider() {
		return this.typeProvider;
	}

	public void setTypeProvider(String typeProvider) {
		this.typeProvider = typeProvider;
	}

}