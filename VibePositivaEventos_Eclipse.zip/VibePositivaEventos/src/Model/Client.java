package Model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the client database table.
 * 
 */
@Entity
@NamedQuery(name="Client.findAll", query="SELECT c FROM Client c")
public class Client implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int idClient;

	private String addressClient;

	private String bankAcClient;

	private String bankAgClient;

	private String bankNumberClient;

	private String cpfClient;

	private String emailClient;

	private String nameClient;

	private String phoneClient;

	public Client() {
	}

	public int getIdClient() {
		return this.idClient;
	}

	public void setIdClient(int idClient) {
		this.idClient = idClient;
	}

	public String getAddressClient() {
		return this.addressClient;
	}

	public void setAddressClient(String addressClient) {
		this.addressClient = addressClient;
	}

	public String getBankAcClient() {
		return this.bankAcClient;
	}

	public void setBankAcClient(String bankAcClient) {
		this.bankAcClient = bankAcClient;
	}

	public String getBankAgClient() {
		return this.bankAgClient;
	}

	public void setBankAgClient(String bankAgClient) {
		this.bankAgClient = bankAgClient;
	}

	public String getBankNumberClient() {
		return this.bankNumberClient;
	}

	public void setBankNumberClient(String bankNumberClient) {
		this.bankNumberClient = bankNumberClient;
	}

	public String getCpfClient() {
		return this.cpfClient;
	}

	public void setCpfClient(String cpfClient) {
		this.cpfClient = cpfClient;
	}

	public String getEmailClient() {
		return this.emailClient;
	}

	public void setEmailClient(String emailClient) {
		this.emailClient = emailClient;
	}

	public String getNameClient() {
		return this.nameClient;
	}

	public void setNameClient(String nameClient) {
		this.nameClient = nameClient;
	}

	public String getPhoneClient() {
		return this.phoneClient;
	}

	public void setPhoneClient(String phoneClient) {
		this.phoneClient = phoneClient;
	}

}