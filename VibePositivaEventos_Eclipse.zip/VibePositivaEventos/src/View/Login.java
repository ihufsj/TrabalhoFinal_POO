package View;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.sun.glass.ui.Menu;

import Controller.UserAccountJPAController;
import Model.Useraccount;
import Utils.EmProvider;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtLoginUserAccount;
	private JTextField txtPasswordUserAccount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setBounds(27, 34, 56, 16);
		contentPane.add(lblLogin);
		
		txtLoginUserAccount = new JTextField();
		txtLoginUserAccount.setBounds(27, 60, 370, 22);
		contentPane.add(txtLoginUserAccount);
		txtLoginUserAccount.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(27, 98, 56, 16);
		contentPane.add(lblSenha);
		
		txtPasswordUserAccount = new JTextField();
		txtPasswordUserAccount.setColumns(10);
		txtPasswordUserAccount.setBounds(27, 124, 370, 22);
		contentPane.add(txtPasswordUserAccount);
		
		JButton btnSignIn = new JButton("Entrar");
		btnSignIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Useraccount toVerify = new Useraccount();
				UserAccountJPAController control = new UserAccountJPAController(EmProvider.getInstance().getEntityManagerFactory());
				Useraccount uc = control.findUserAccountByLogin(txtLoginUserAccount.getText());
				if(uc.getPasswordUserAccount().equals(txtPasswordUserAccount.getText())) {
					Main m = new Main();
					m.setVisible(true);
				}
			}
		});
		btnSignIn.setBounds(115, 174, 97, 25);
		contentPane.add(btnSignIn);
		
		JButton btnSignUp = new JButton("Cadastre-se");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateUserAccount uc = new CreateUserAccount();
				uc.setVisible(true);
			}
		});
		btnSignUp.setBounds(221, 174, 119, 25);
		contentPane.add(btnSignUp);
	}

}
