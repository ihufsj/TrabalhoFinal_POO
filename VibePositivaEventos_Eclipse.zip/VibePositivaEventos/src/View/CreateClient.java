package View;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Controller.ClientJPAController;
import Model.Client;
import Utils.EmProvider;

public class CreateClient extends JFrame {

	private JPanel contentPane;
	private JTextField txtNameClient;
	private JTextField txtPhoneClient;
	private JTextField txtAddressClient;
	private JLabel lblDigiteOEndereo;
	private JTextField txtEmailClient;
	private JLabel lblDigiteOEmail;
	private JTextField txtAgClient;
	private JLabel lblDigiteAAgencia;
	private JTextField txtCcClient;
	private JLabel lblDigiteAConta;
	private JLabel lblDigiteONmero;
	private JTextField txtBankNumberClient;
	private JLabel lblDigiteONmero_1;
	private JTextField txtCpfClient;
	private JButton btnCreateClient;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateClient frame = new CreateClient();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateClient() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 664);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDigiteONome = new JLabel("digite o nome do cliente");
		lblDigiteONome.setBounds(12, 13, 391, 16);
		contentPane.add(lblDigiteONome);
		
		txtNameClient = new JTextField();
		txtNameClient.setBounds(12, 42, 408, 22);
		contentPane.add(txtNameClient);
		txtNameClient.setColumns(10);
		
		JLabel lblDigiteOTelefone = new JLabel("digite o telefone do cliente");
		lblDigiteOTelefone.setBounds(12, 77, 391, 16);
		contentPane.add(lblDigiteOTelefone);
		
		txtPhoneClient = new JTextField();
		txtPhoneClient.setColumns(10);
		txtPhoneClient.setBounds(12, 106, 408, 22);
		contentPane.add(txtPhoneClient);
		
		txtAddressClient = new JTextField();
		txtAddressClient.setColumns(10);
		txtAddressClient.setBounds(12, 170, 408, 22);
		contentPane.add(txtAddressClient);
		
		lblDigiteOEndereo = new JLabel("digite o endere\u00E7o do cliente");
		lblDigiteOEndereo.setBounds(12, 141, 391, 16);
		contentPane.add(lblDigiteOEndereo);
		
		txtEmailClient = new JTextField();
		txtEmailClient.setColumns(10);
		txtEmailClient.setBounds(12, 239, 408, 22);
		contentPane.add(txtEmailClient);
		
		lblDigiteOEmail = new JLabel("digite o email do cliente");
		lblDigiteOEmail.setBounds(12, 210, 391, 16);
		contentPane.add(lblDigiteOEmail);
		
		txtAgClient = new JTextField();
		txtAgClient.setColumns(10);
		txtAgClient.setBounds(12, 314, 408, 22);
		contentPane.add(txtAgClient);
		
		lblDigiteAAgencia = new JLabel("digite a agencia banc\u00E1ria do cliente");
		lblDigiteAAgencia.setBounds(12, 285, 391, 16);
		contentPane.add(lblDigiteAAgencia);
		
		txtCcClient = new JTextField();
		txtCcClient.setColumns(10);
		txtCcClient.setBounds(12, 395, 408, 22);
		contentPane.add(txtCcClient);
		
		lblDigiteAConta = new JLabel("digite a conta banc\u00E1ria do cliente");
		lblDigiteAConta.setBounds(12, 366, 391, 16);
		contentPane.add(lblDigiteAConta);
		
		lblDigiteONmero = new JLabel("Digite o n\u00FAmero do banco do cliente");
		lblDigiteONmero.setBounds(12, 442, 391, 16);
		contentPane.add(lblDigiteONmero);
		
		txtBankNumberClient = new JTextField();
		txtBankNumberClient.setColumns(10);
		txtBankNumberClient.setBounds(12, 471, 408, 22);
		contentPane.add(txtBankNumberClient);
		
		lblDigiteONmero_1 = new JLabel("Digite o n\u00FAmero o CPF do cliente");
		lblDigiteONmero_1.setBounds(12, 515, 391, 16);
		contentPane.add(lblDigiteONmero_1);
		
		txtCpfClient = new JTextField();
		txtCpfClient.setColumns(10);
		txtCpfClient.setBounds(12, 544, 408, 22);
		contentPane.add(txtCpfClient);
		
		btnCreateClient = new JButton("Cadastrar");
		btnCreateClient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Client c = new Client();
				c.setNameClient(txtNameClient.getText());
				c.setPhoneClient(txtPhoneClient.getText());
				c.setAddressClient(txtAddressClient.getText());
				c.setEmailClient(txtEmailClient.getText());
				c.setCpfClient(txtCpfClient.getText());
				c.setBankAcClient(txtCcClient.getText());
				c.setBankAgClient(txtAgClient.getText());
				c.setBankNumberClient(txtBankNumberClient.getText());
				ClientJPAController control = new ClientJPAController(EmProvider.getInstance().getEntityManagerFactory());
				if (control.create(c)) {
					JFrame f;
					f = new JFrame();
					JOptionPane.showMessageDialog(f, "Criado com sucesso!", "Alert", JOptionPane.WARNING_MESSAGE);
				}else {
					JFrame f;
					f = new JFrame();
					JOptionPane.showMessageDialog(f, "Houve um erro na inser��o!", "Alert", JOptionPane.WARNING_MESSAGE);
				}
				
			}
		});
		btnCreateClient.setBounds(157, 579, 97, 25);
		contentPane.add(btnCreateClient);
	}

}
