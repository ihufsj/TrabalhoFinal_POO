package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 432, 26);
		contentPane.add(menuBar);
		
		JMenu mnCadastrar = new JMenu("Cadastrar");
		menuBar.add(mnCadastrar);
		
		JMenuItem mnCreateCliente = new JMenuItem("Cliente");
		mnCreateCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateClient cc = new CreateClient();
				cc.setVisible(true);
			}
		});
		mnCadastrar.add(mnCreateCliente);
		
		JMenuItem mnCreateUser = new JMenuItem("Usu\u00E1rio");
		mnCreateUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateUserAccount cc = new CreateUserAccount();
				cc.setVisible(true);
			}
		});
		mnCadastrar.add(mnCreateUser);
		
		JMenuItem mnProvider = new JMenuItem("Fornecedor");
		mnProvider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CreateProvider p = new CreateProvider();
				p.setVisible(true);
			}
		});
		mnCadastrar.add(mnProvider);
		
		JMenu mnRelatrios = new JMenu("Relat\u00F3rios");
		menuBar.add(mnRelatrios);
		
		JLabel lblGoodvibeseventos = new JLabel("GoodVibesEventos");
		lblGoodvibeseventos.setHorizontalAlignment(SwingConstants.CENTER);
		lblGoodvibeseventos.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGoodvibeseventos.setBounds(149, 125, 258, 16);
		contentPane.add(lblGoodvibeseventos);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\vini_\\OneDrive\\\u00C1rea de Trabalho\\goodvibesproject\\logo.jpg"));
		lblNewLabel.setBounds(32, 70, 105, 135);
		contentPane.add(lblNewLabel);
	}
}
