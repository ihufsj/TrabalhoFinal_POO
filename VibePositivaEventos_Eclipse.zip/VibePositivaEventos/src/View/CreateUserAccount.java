package View;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Controller.UserAccountJPAController;
import Model.Useraccount;
import Utils.EmProvider;

public class CreateUserAccount extends JFrame {

	private JPanel contentPane;
	private JTextField txtNameUserAccount;
	private JTextField txtLoginUserAccount;
	private JTextField txtPasswordUserAccount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateUserAccount frame = new CreateUserAccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateUserAccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 320);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblName = new JLabel("Digite o nome do usuario");
		lblName.setBounds(12, 13, 410, 16);
		contentPane.add(lblName);

		txtNameUserAccount = new JTextField();
		txtNameUserAccount.setBounds(10, 42, 412, 22);
		contentPane.add(txtNameUserAccount);
		txtNameUserAccount.setColumns(10);

		JLabel lblDigiteOLogin = new JLabel("digite o login do usu\u00E1rio");
		lblDigiteOLogin.setBounds(12, 77, 402, 16);
		contentPane.add(lblDigiteOLogin);

		txtLoginUserAccount = new JTextField();
		txtLoginUserAccount.setBounds(10, 110, 412, 22);
		contentPane.add(txtLoginUserAccount);
		txtLoginUserAccount.setColumns(10);

		JLabel lblDigiteASenha = new JLabel("Digite a senha do usu\u00E1rio");
		lblDigiteASenha.setBounds(12, 145, 408, 16);
		contentPane.add(lblDigiteASenha);

		txtPasswordUserAccount = new JTextField();
		txtPasswordUserAccount.setBounds(10, 174, 412, 22);
		contentPane.add(txtPasswordUserAccount);
		txtPasswordUserAccount.setColumns(10);

		JButton btnCreate = new JButton("Cadastrar");
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Useraccount uc = new Useraccount();
				uc.setNameUserAccount(txtNameUserAccount.getText());
				uc.setLoginUserAccount(txtLoginUserAccount.getText());
				uc.setPasswordUserAccount(txtPasswordUserAccount.getText());
				UserAccountJPAController control = new UserAccountJPAController(
						EmProvider.getInstance().getEntityManagerFactory());
				if (control.create(uc)) {
					JFrame f;
					f = new JFrame();
					JOptionPane.showMessageDialog(f, "Criado com sucesso!", "Alert", JOptionPane.WARNING_MESSAGE);
				}else {
					JFrame f;
					f = new JFrame();
					JOptionPane.showMessageDialog(f, "Houve um erro na inser��o!", "Alert", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnCreate.setBounds(167, 222, 97, 25);
		contentPane.add(btnCreate);
	}
}
