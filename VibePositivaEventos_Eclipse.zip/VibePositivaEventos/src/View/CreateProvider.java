package View;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Controller.ProviderJPAController;
import Model.Provider;
import Utils.EmProvider;

public class CreateProvider extends JFrame {

	private JPanel contentPane;
	private JTextField txtNameProvider;
	private JTextField txtPhoneProvider;
	private JTextField txtAddressProvider;
	private JTextField txtCNPJProvider;
	private JTextField txtEmailProvider;
	private JTextField txtTipoProvider;
	private JTextField txtAgencyProvider;
	private JTextField txtAccountProvider;
	private JTextField txtBankNumberProvider;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateProvider frame = new CreateProvider();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateProvider() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 762);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDigiteONome = new JLabel("Digite o nome do fornecedor");
		lblDigiteONome.setBounds(12, 13, 390, 16);
		contentPane.add(lblDigiteONome);
		
		txtNameProvider = new JTextField();
		txtNameProvider.setBounds(12, 42, 408, 22);
		contentPane.add(txtNameProvider);
		txtNameProvider.setColumns(10);
		
		JLabel lblDigiteOTelefone = new JLabel("Digite o telefone do fornecedor");
		lblDigiteOTelefone.setBounds(12, 77, 390, 16);
		contentPane.add(lblDigiteOTelefone);
		
		txtPhoneProvider = new JTextField();
		txtPhoneProvider.setColumns(10);
		txtPhoneProvider.setBounds(12, 106, 408, 22);
		contentPane.add(txtPhoneProvider);
		
		JLabel lblDigiteOEndereo = new JLabel("Digite o  endere\u00E7o do fornecedor");
		lblDigiteOEndereo.setBounds(12, 151, 390, 16);
		contentPane.add(lblDigiteOEndereo);
		
		txtAddressProvider = new JTextField();
		txtAddressProvider.setColumns(10);
		txtAddressProvider.setBounds(12, 180, 408, 22);
		contentPane.add(txtAddressProvider);
		
		JLabel lblDigiteOCnpj = new JLabel("Digite o cnpj do fornecedor");
		lblDigiteOCnpj.setBounds(12, 224, 390, 16);
		contentPane.add(lblDigiteOCnpj);
		
		txtCNPJProvider = new JTextField();
		txtCNPJProvider.setColumns(10);
		txtCNPJProvider.setBounds(12, 253, 408, 22);
		contentPane.add(txtCNPJProvider);
		
		JLabel lblDigiteOEmail = new JLabel("Digite o email do fornecedor");
		lblDigiteOEmail.setBounds(12, 288, 390, 16);
		contentPane.add(lblDigiteOEmail);
		
		txtEmailProvider = new JTextField();
		txtEmailProvider.setColumns(10);
		txtEmailProvider.setBounds(12, 317, 408, 22);
		contentPane.add(txtEmailProvider);
		
		JLabel lblDigiteOTipo = new JLabel("Digite o tipo do fornecedor");
		lblDigiteOTipo.setBounds(12, 352, 390, 16);
		contentPane.add(lblDigiteOTipo);
		
		txtTipoProvider = new JTextField();
		txtTipoProvider.setColumns(10);
		txtTipoProvider.setBounds(12, 381, 408, 22);
		contentPane.add(txtTipoProvider);
		
		JLabel lblDigiteOAgencia = new JLabel("Digite o Agencia do fornecedor");
		lblDigiteOAgencia.setBounds(12, 427, 390, 16);
		contentPane.add(lblDigiteOAgencia);
		
		txtAgencyProvider = new JTextField();
		txtAgencyProvider.setColumns(10);
		txtAgencyProvider.setBounds(12, 456, 408, 22);
		contentPane.add(txtAgencyProvider);
		
		JLabel lblDigiteOConta = new JLabel("Digite o conta do fornecedor");
		lblDigiteOConta.setBounds(12, 501, 390, 16);
		contentPane.add(lblDigiteOConta);
		
		txtAccountProvider = new JTextField();
		txtAccountProvider.setColumns(10);
		txtAccountProvider.setBounds(12, 530, 408, 22);
		contentPane.add(txtAccountProvider);
		
		JLabel lblDigiteONumero = new JLabel("Digite o numero do banco do fornecedor");
		lblDigiteONumero.setBounds(12, 577, 390, 16);
		contentPane.add(lblDigiteONumero);
		
		txtBankNumberProvider = new JTextField();
		txtBankNumberProvider.setColumns(10);
		txtBankNumberProvider.setBounds(12, 606, 408, 22);
		contentPane.add(txtBankNumberProvider);
		
		JButton btnCadastrarFornecedor = new JButton("Cadastrar fornecedor");
		btnCadastrarFornecedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Provider p = new Provider();
				p.setNameProvider(txtNameProvider.getText());
				p.setPhoneProvider(txtPhoneProvider.getText());
				p.setCnpjProvider(txtCNPJProvider.getText());
				p.setTypeProvider(txtTipoProvider.getText());
				p.setBankAcProvider(txtAccountProvider.getText());
				p.setBankAgProvider(txtAgencyProvider.getText());
				p.setBankNumberProvider(txtBankNumberProvider.getText());
				ProviderJPAController control = new ProviderJPAController(EmProvider.getInstance().getEntityManagerFactory());
				if (control.create(p)) {
					JFrame f;
					f = new JFrame();
					JOptionPane.showMessageDialog(f, "Criado com sucesso!", "Alert", JOptionPane.WARNING_MESSAGE);
				}else {
					JFrame f;
					f = new JFrame();
					JOptionPane.showMessageDialog(f, "Houve um erro na inser��o!", "Alert", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnCadastrarFornecedor.setBounds(118, 654, 191, 25);
		contentPane.add(btnCadastrarFornecedor);
	}
}
